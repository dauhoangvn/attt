wget https://download.checkmk.com/checkmk/2.0.0p39/check-mk-raw-2.0.0p39_0.focal_amd64.deb

gdebi -n check-mk-raw-2.0.0p39_0.focal_amd64.deb
omd create monitoring
omd start monitoring
omd su monitoring


